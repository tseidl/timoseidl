The folder contains the following files

1) A R script ("Politics of Platform Work_Replication Code.R") containing replication code for the figures presented in the paper and the online appendix. 

2) A RData file("frames.RData") which contains a data frame with information on the frames used (and on which Figure 2 and Figure 5 are based)

3) A dna file ("Uber_NY.dna") which contains the results of our analysis. It can be opened with the software Discourse Network Analyser (for details, see  Leifeld, Philipp; Gruber, Johannes; Bosner, Felix Rolf: Discourse Network Analyzer Manual).