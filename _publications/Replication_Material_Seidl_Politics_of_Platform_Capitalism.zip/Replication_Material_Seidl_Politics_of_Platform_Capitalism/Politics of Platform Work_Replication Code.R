############################################################################
############################################################################
###                                                                      ###
###        THE POLITICS OF PLATFORM CAPITALISM - REPLICATION CODE        ###
###                                                                      ###
############################################################################
############################################################################

#The following code replicates the network and bar plots from the paper:
#"The politics of platform capitalism. A case study on the regulation of Uber in New York"
#The neccessary data can be obtained from the supplementary materials.


##################################################################
##                Installing & Loading Libraries                ##
##################################################################

#if you have difficulties loading the rJava or rDNA package, 
#please consult the most recent version of Leifeld, Philipp; Gruber, Johannes; Bosner, Felix Rolf: Discourse Network Analyzer Manual.


packages <- c("devtools", "rDNA", "rJava", "igraph", "tidyverse", "ggplot2", "RColorBrewer")

missing.packages <- which(!packages %in% installed.packages()[, "Package"])
if (length(missing.packages)) install.packages(packages[missing.packages])
lapply(packages, require, character.only = T)



########################################################################################################
##  Getting Started with rDNA and Retrieving Networks and Attributes from Discourse Network Analyser  ##
########################################################################################################


dna_downloadJar() #download the current betaversion of DNA into working directory


dna_init()  #initializing DNA (using the current version downloaded into the working directory)


dna_gui("Uber_NY.dna") #opening DNA file in the working directory for inspection in Discourse Network Analyser (optional)


conn <- dna_connection("Uber_NY.dna") #establish a connection with the Discourse Network Analyser Database (files need to be in working directory)



#################################################################
##                  Actor Congurence Networks                  ##
#################################################################


congruence <- dna_network(conn,
                          networkType = "onemode",
                          statementType = "DNA Statement",
                          variable1 = "organization",
                          variable2 = "concept",
                          qualifier = "agreement",
                          qualifierAggregation = "congruence",
                          normalization = "average",
                          duplicates = "week",
                          start.date = "10.09.2013",
                          stop.date = "01.08.2015",
                          excludeValues = list("Category" = "TLC Regulation", "Category" = "State Level Regulation"))# excluding codes on TLC and State-Level Regulation


#degree centrality

de_cen <- degree(graph.adjacency(congruence, mode="undirected", weighted=T))

#ploting the network, manually assigning colors that make intuitive sense (e.g. yellow and orange for taxi drivers and taxi industry)

custom_color <- c("#6A3D9A", "#A6CEE3", "#E31A1C", "#FF7F00", "#CAB2D6","#B2DF8A","#FB9A99", "#33A02C", "#FDBF6F", "#1F78B4")

dna_plotNetwork(
  congruence,
  layout = "stress",
  node_size = sqrt(de_cen),
  edge_alpha = 1,
  node_attribute = "type",
  label_repel = 0.1,
  font_size = 7,
  node_colors = "manual",
  custom_colors = custom_color,
  show_legend = F
)+
  theme(legend.position = "bottom")


#second period


congruence2 <- dna_network(conn,
                          networkType = "onemode",
                          statementType = "DNA Statement",
                          variable1 = "organization",
                          variable2 = "concept",
                          qualifier = "agreement",
                          qualifierAggregation = "congruence",
                          normalization = "average",
                          duplicates = "week",
                          start.date = "02.08.2015",
                          stop.date = "31.12.2018",
                          excludeValues = list("Category" = "TLC Regulation", "Category" = "State Level Regulation"))



de_cen2 <- degree(graph.adjacency(congruence2, mode="undirected", weighted=T))

#ploting the network, manually assigning colors that make intuitive sense (e.g. yellow and orange for taxi drivers and taxi industry)

dna_plotNetwork(
  congruence2,
  layout = "stress",
  node_size = sqrt(de_cen2),
  edge_alpha = 1,
  node_attribute = "type",
  label_repel = 0.1,
  font_size = 7,
  node_colors = "manual",
  custom_colors = custom_color,
  show_legend = F
)+
  theme(legend.position = "bottom")



#################################################################
##                       Barplots Frames                       ##
#################################################################


#first period

frames_one <- frames %>%
  filter(period == "first") %>%
  select(-period) %>%
  filter(
    Frame %in% c(
      "Exclusion/Discrimination",
      "Collusion/Corruption",
      "Working Conditions/Drivers’ Interests",
      "Consumer Interests",
      "Congestion",
      "Economy/Jobs/Innovation",
      "Public Interest",
      "Disability Rights",
      "Environment",
      "Safety"
    )
  )%>%
  mutate(Pro_de_Blasio = Pro_de_Blasio - Statements_de_Blasio) %>% #here just subtract deBlasio's statements from the statments by the de Blasio camp
  mutate(Pro_Uber = Pro_Uber - Statements_Uber) %>% #same for Uber (allows for easier visualization as one can just take for groups)
  mutate(Pro_de_Blasio = Pro_de_Blasio * -1) %>% #so that they are negative, again for plotting
  mutate(Statements_de_Blasio = Statements_de_Blasio * -1) %>%
  gather(pro, value, Pro_Uber:Statements_de_Blasio, factor_key = TRUE)%>%#make wide too long
  mutate(pro = ordered(pro, c(
    "Pro_de_Blasio",  
    "Statements_de_Blasio",
    "Pro_Uber",
      "Statements_Uber"
    )
  ))


#plotting

#extract colors red and blue from the "paired" palette

custom_color <- c("#A6CEE3", "#1F78B4", "#FB9A99", "#E31A1C")



ggplot(frames_one, aes(x = reorder(Frame, value), value, fill = pro)) +
  geom_col(show.legend = T, width = 0.7) +
  coord_flip() +
  labs(x = "",
       y = "Number of Statements") +
  scale_y_continuous(labels = abs, limits = c(-35, 35))+ #absolute values not minus
  geom_hline(yintercept = 0) +
  theme_bw() +
  theme(legend.position = "bottom") +
  scale_fill_manual(
    values = custom_color,
    name = "",
    labels = c(
      "Statements de Blasio Coalition",
      "Statments de Blasio",
      "Statements Uber Coalition",
      "Statements Uber"
    )
  ) +
  ggtitle("Statements pro de Blasio/pro cap                Statements pro Uber/against cap") +
  theme(plot.title = element_text(hjust = 0.5, size = 16, face = "bold.italic" ))+
  theme(text = element_text(size = 20))+
  guides(fill=guide_legend(nrow=2,byrow=TRUE))




#second period

frames_two <- frames %>%
  filter(period == "second") %>%
  select(-period) %>%
  filter(
    Frame %in% c(
      "Exclusion/Discrimination",
      "Collusion/Corruption",
      "Working Conditions/Drivers’ Interests",
      "Consumer Interests",
      "Congestion",
      "Economy/Jobs/Innovation",
      "Public Interest",
      "Disability Rights",
      "Environment",
      "Safety",
      "Congestion Pricing"
    )
  )%>%
  mutate(Pro_de_Blasio = Pro_de_Blasio-Statements_de_Blasio)%>%#here just subtract deBlasio's statements from the statments by the de Blasio camp
  mutate(Pro_Uber = Pro_Uber-Statements_Uber)%>%#same for Uber (allows for easier visualization as one can just take for groups)
  mutate(Pro_de_Blasio = Pro_de_Blasio*-1)%>%#so that they are negative, again for plotting
  mutate(Statements_de_Blasio = Statements_de_Blasio*-1)%>%
  gather(pro, value, Pro_Uber:Statements_de_Blasio, factor_key=TRUE)%>%#make wide too long
  mutate(pro = ordered(pro, c(
    "Pro_de_Blasio",  
    "Statements_de_Blasio",
    "Pro_Uber",
    "Statements_Uber"
  )
  ))


#plotting

#extract colors red and blue from the "paired" palette

custom_color <- c("#A6CEE3", "#1F78B4", "#FB9A99", "#E31A1C")


ggplot(frames_two, aes(x = reorder(Frame, value), value, fill = pro)) +
  geom_col(show.legend = T, width = 0.7) +
  coord_flip() +
  labs(x = "",
       y = "Number of Statements") +
  scale_y_continuous(labels = abs, limits = c(-70, 70), breaks = c(-60, -40, -20, 0, 20, 40, 60)) + #absolute values not minus
  geom_hline(yintercept = 0) +
  theme_bw() +
  theme(legend.position = "bottom") +
  scale_fill_manual(
    values = custom_color,
    name = "",
    labels = c(
      "Statements de Blasio Coalition",
      "Statments de Blasio",
      "Statements Uber Coalition",
      "Statements Uber"
    )
  ) +
  ggtitle("Statements pro de Blasio/pro cap        Statements pro Uber/against cap") +
  theme(plot.title = element_text(hjust = 0.5, size = 16, face = "bold.italic" ))+
  theme(text = element_text(size = 20))+
  guides(fill=guide_legend(nrow=2,byrow=TRUE))




##################################################################
##                       Cluster Analysis                       ##
##################################################################



mc <- dna_multiclust(conn,
                     statementType = "DNA Statement",
                     variable1 = "organization",
                     variable2 = "concept",
                     qualifier = "agreement",
                     duplicates = "week",
                     start.date = "10.09.2013",
                     stop.date = "01.08.2015",
                     excludeValues = list("Category" = "TLC Regulation", "Category" = "State Level Regulation"),
                     k.max = 5,
                     single = F,
                     average = F,
                     complete = F,
                     ward = FALSE,
                     kmeans = T,
                     pam = FALSE,
                     equivalence = T,
                     concor_one = FALSE,
                     concor_two = FALSE,
                     louvain = T,
                     fastgreedy = T,
                     walktrap = T,
                     leading_eigen = T,
                     edge_betweenness = T,
                     infomap = T,
                     label_prop = FALSE,
                     spinglass = FALSE
)

mc2 <- dna_multiclust(conn,
                     statementType = "DNA Statement",
                     variable1 = "organization",
                     variable2 = "concept",
                     qualifier = "agreement",
                     duplicates = "week",
                     start.date = "02.08.2015",
                     stop.date = "31.12.2018",
                     excludeValues = list("Category" = "TLC Regulation", "Category" = "State Level Regulation"),
                     k.max = 5,
                     single = F,
                     average = F,
                     complete = F,
                     ward = FALSE,
                     kmeans = T,
                     pam = FALSE,
                     equivalence = T,
                     concor_one = FALSE,
                     concor_two = FALSE,
                     louvain = T,
                     fastgreedy = T,
                     walktrap = T,
                     leading_eigen = T,
                     edge_betweenness = T,
                     infomap = T,
                     label_prop = FALSE,
                     spinglass = FALSE
)



#creating dataframe for first period

memberships <- mc1$memberships

#or for second period

memberships <- mc2$memberships

#selecting cluster algorhitms separately

#louvain

sel_mem <- memberships%>%
  filter(method=="Louvain")

#creating named vector

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

#ploting 

louvain <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Louvain",
          subtitle = "Colors indicate cluster membership")

#k-means

sel_mem <- memberships%>%
  filter(method=="k-Means")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

kmeans <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("K-Means",
          subtitle = "Colors indicate cluster membership")

#fast&greedy

sel_mem <- memberships%>%
  filter(method=="Fast & Greedy")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

fastngreedy <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Fast & Greedy",
          subtitle = "Colors indicate cluster membership")

#leading eigenvector

sel_mem <- memberships%>%
  filter(method=="Leading Eigenvector")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

leadeigen <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Leading Eigenvector",
          subtitle = "Colors indicate cluster membership")


#edge betweenness

sel_mem <- memberships%>%
  filter(method=="Edge Betweenness")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

edge_bet <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Edge Betweenness",
          subtitle = "Colors indicate cluster membership")

#walktrap

sel_mem <- memberships%>%
  filter(method=="Walktrap")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

walktrap <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Walktrap",
          subtitle = "Colors indicate cluster membership")

#infomap

sel_mem <- memberships%>%
  filter(method=="Infomap")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

infomap <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Infomap",
          subtitle = "Colors indicate cluster membership")


#equivalence


sel_mem <- memberships%>%
  filter(method=="Equivalence")

groups <- structure(as.character(sel_mem$cluster), names = as.character(sel_mem$node))

equivalence <- dna_plotNetwork(
  congruence,
  layout = "nicely",
  node_attribute = "group",
  groups = groups,
  node_size = 2,
  show_legend = F, 
  seed = 1234
)+
  ggtitle("Equivalance",
          subtitle = "Colors indicate cluster membership")

#grid arrange

gridExtra::grid.arrange(equivalence, leadeigen, edge_bet, walktrap)

gridExtra::grid.arrange(infomap, fastngreedy, louvain, kmeans)




##################################################################
##                      Sentiment Analysis                      ##
##################################################################



#sentiment score bing

bing <- corpus_tidy_new %>%
  inner_join(get_sentiments("bing"))%>%
  group_by(origin, Date)%>% #in combination with complete to retain variable
  dplyr::count(heading, sentiment, .drop = F)%>%
  complete(origin, Date)%>%
  spread(sentiment, n, fill=0)%>%
  mutate(sentiment = positive-negative)%>%
  ungroup()%>%
  mutate(method = "Bing Liu et al.")%>%
  mutate(month = format(Date, "%m"), year = format(Date, "%Y"))%>%
  group_by(month, year)%>%
  dplyr::mutate(total = mean(sentiment))%>%
  dplyr::select(-c("negative", "positive"))


#importing the lexicoder dictionary

lexicoder <- data_dictionary_LSD2015%>%
  tidy()%>%
  dplyr::rename(sentiment = category)%>%
  select(word, sentiment)



lexicod <- corpus_tidy_new %>%
  inner_join(lexicoder)%>%
  group_by(origin, Date)%>% #in combination with complete to retain variable
  dplyr::count(heading, sentiment, .drop = F)%>%
  complete(origin, Date)%>%
  spread(sentiment, n, fill=0)%>%
  mutate(sentiment = positive-negative)%>%
  ungroup()%>%
  mutate(method = "Lexicoder")%>%
  mutate(month = format(Date, "%m"), year = format(Date, "%Y"))%>%
  group_by(month, year)%>%
  dplyr::mutate(total = mean(sentiment))%>%
  dplyr::select(-c("negative", "positive"))



#affin dictionary


afinn <- corpus_tidy_new %>% 
  inner_join(get_sentiments("afinn"))%>% 
  group_by(heading, origin, Date)%>% 
  dplyr::summarise(sentiment = sum(value))%>%
  complete(origin, Date)%>%
  ungroup()%>%
  mutate(method = "AFINN")%>%
  mutate(month = format(Date, "%m"), year = format(Date, "%Y"))%>%
  group_by(month, year)%>%
  dplyr::mutate(total = mean(sentiment))


ggplot(afinn, aes(Date, sentiment, fill = origin)) +
  geom_col(show.legend = FALSE)+
  geom_line(data = afinn, aes(Date, total), color = "black", size = 1, linetype = 3)+
  scale_x_date(limits = as.Date(c("2013-09-01","2018-12-31")))+
  facet_wrap(~origin, ncol = 1)


#loughran (for financial texts)


loughran <- corpus_tidy_new %>%
  inner_join(get_sentiments("loughran"))%>%
  group_by(origin, Date)%>% #in combination with complete to retain variable
  dplyr::count(heading, sentiment, .drop = F)%>%
  complete(origin, Date)%>%
  spread(sentiment, n, fill=0)%>%
  mutate(sentiment = positive-negative)%>%
  ungroup()%>%
  mutate(method = "Loughran")%>%
  mutate(month = format(Date, "%m"), year = format(Date, "%Y"))%>%
  group_by(month, year)%>%
  dplyr::mutate(total = mean(sentiment))%>%
  dplyr::select(-c("negative", "positive"))

#nrc

nrc <- corpus_tidy_new %>%
  inner_join(get_sentiments("nrc")) %>%
  filter(sentiment %in% c("positive",
                          "negative")) %>%
  group_by(origin, Date) %>% #in combination with complete to retain variable
  dplyr::count(heading, sentiment, .drop = F) %>%
  complete(origin, Date) %>%
  spread(sentiment, n, fill = 0)%>%
  mutate(sentiment = positive - negative) %>%
  ungroup()%>%
  mutate(method = "NRC")%>%
  mutate(month = format(Date, "%m"), year = format(Date, "%Y"))%>%
  group_by(month, year)%>%
  dplyr::mutate(total = mean(sentiment))%>%
  dplyr::select(-c("negative", "positive"))



#binding rows

sent_comb <- bind_rows(afinn, 
                       bing)#without nrc, loughran, lexicod


#calculating average score before and after

sent_comb <- sent_comb%>%
  mutate(period = ifelse(Date <= as.Date("2015-07-22"), 1, 2))

#calculating effect size

cohen.d(sent_comb$sentiment, as.factor(sent_comb$period), hedges.correction = T)

#plotting

ggplot(sent_comb, aes(Date, sentiment, fill = method)) +
  geom_col(show.legend = FALSE) +
  scale_x_date(breaks = "1 year", date_labels = "%Y") +
  facet_wrap(~ method, ncol = 1) +
  labs(
    x = "Year",
    y = "Sentiment"
  )+
  geom_vline(xintercept = as.numeric(as.Date("2015-07-22")),
             linetype = 4) +
  geom_vline(xintercept = as.numeric(as.Date("2018-08-08")),
             linetype = 4) +
  theme_bw()



